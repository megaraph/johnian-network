function showGif() {
    document.getElementById('submitBtn').style.display = "none";
    document.getElementById('loadingGif').style.display = "block";
}